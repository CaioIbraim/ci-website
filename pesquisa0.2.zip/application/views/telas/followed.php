


        <div class="row">
            <div class="col-md-4">
                <h2>Seguindo</h3>
                  {dtSeg}
                  <p>{seguindo}</p>
                  <p>{solicitacao}</p>
            </div>
            <div class="col-md-4">
                <h2>Sugestões</h3>
                  <p>{sugest}</p>
            </div>
            <div class="col-md-4">
                <h2>Seguidores</h3>
                    {seguidores}<p>{nome}</p>{/seguidores}
            </div>
        </div>
