
<div class="section section-images">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Solicitações de colaboração</h3>
                  {sol} <p>  <a href="<?= base_url();?>/follow/acept/{id_login}"/>  {nome} </a></p>{/sol}
            </div>
        </div>
    </div>
</div>
