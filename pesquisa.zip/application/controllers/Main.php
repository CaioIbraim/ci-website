<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class main extends MY_Controller {

    public function __construct() {
      parent::__construct();
      $this->data['title'] = 'Main';
      $this->data['url_pagina'] = base_url().''.$this->uri->segment(1);
      if($this->session->login === NULL || $this->session->login === FALSE){
        redirect('login/logout');
      }
    }
    
    public function index() {
        $this->parser->parse('layout/landing', $this->data);
    }
}
