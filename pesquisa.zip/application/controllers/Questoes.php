<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class questoes extends MY_Controller {

    public function __construct() {
      parent::__construct();
      $this->data['title'] = 'Questões';
      $this->data['url_pagina'] = base_url().''.$this->uri->segment(1);
    }

    public function index() {
      //Retornar as questões cadatradas
      $this->parser->parse('layout/login', $this->data);
    }

    public function criar($id){

      if(empty($id)){
        die('Informe a pesquisa');
      }

      $this->load->model('Crud_model', 'p');
      $v = $this->p->select_where('id_pesquisa',$id, 'pesquisa'); //Verifico se já existe cadastro para o usuário
      if(count($v) === 0){
        die('Pesquisa não encontrada.');
      }
      //var_dump($v); die();

      $this->data['titulo'] = $v[0]['titulo'];
      $this->data['id'] = $id;

      $this->data['conteudo'] = $this->parser->parse('telas/questoes', $this->data, true);
      $this->parser->parse('layout/landing', $this->data);
    }

    public function cadastrar(){
      $dados = $this->input->post();

      if($dados['tipo'] === NULL){
        die('selecione o tipo');
      }

      if(empty($dados['a'])){
        die('Preencha todas as opções');
      }

      if(empty($dados['b'])){
        die('Preencha todas as opções');
      }

      if(empty($dados['c'])){
        die('Preencha todas as opções');
      }


      if(empty($dados['d'])){
        die('Preencha todas as opções');
      }

      if(empty($dados['e'])){
        die('Preencha todas as opções');
      }

      if($dados['id_pesquisa '] === ""){
          die('Informe uma senha');
      }

        $this->load->model('Crud_model', 'p');
        $query = $this->p->insert($dados,'questao');
        die('dados cadastrados');
      }
}
