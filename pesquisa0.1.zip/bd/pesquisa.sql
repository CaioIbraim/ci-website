-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 13-Abr-2018 às 21:23
-- Versão do servidor: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pesquisa`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `escolha`
--

CREATE TABLE `escolha` (
  `id_escolha` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `fk_login` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `fk_questao` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `opc_escolhida` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `escolha`
--

INSERT INTO `escolha` (`id_escolha`, `fk_login`, `fk_questao`, `opc_escolhida`) VALUES
(0001, 0001, 0001, 'a'),
(0002, 0001, 0002, 'e'),
(0003, 0003, 0001, 'a'),
(0004, 0003, 0002, 'a');

-- --------------------------------------------------------

--
-- Estrutura da tabela `follow`
--

CREATE TABLE `follow` (
  `id_follow` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `follower` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `followed` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

CREATE TABLE `login` (
  `id_login` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `perfil` int(2) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `titulo` varchar(25) NOT NULL,
  `cel` varchar(20) NOT NULL,
  `email` varchar(260) DEFAULT NULL,
  `senha` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login` (`id_login`, `perfil`, `nome`, `titulo`, `cel`, `email`, `senha`) VALUES
(0001, 1, 'Caio', '', '2126059692', 'caiofabiocosta@gmail.com', '213c437c777a79173173f9a235035c95'),
(0002, 2, 'Caio Ibraim', '', '21968639055', 'ibraim.caiofabio@gmail.com', '213c437c777a79173173f9a235035c95'),
(0003, 1, 'Felipe', '', '21989132062', 'felipe.iduff@uff.com', '213c437c777a79173173f9a235035c95');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pesquisa`
--

CREATE TABLE `pesquisa` (
  `id_pesquisa` int(4) UNSIGNED ZEROFILL NOT NULL,
  `dt_ini` date NOT NULL,
  `dt_fim` date NOT NULL,
  `status` int(1) NOT NULL,
  `titulo` varchar(64) NOT NULL,
  `autor` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `descricao` text NOT NULL,
  `perfil` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pesquisa`
--

INSERT INTO `pesquisa` (`id_pesquisa`, `dt_ini`, `dt_fim`, `status`, `titulo`, `autor`, `descricao`, `perfil`) VALUES
(0001, '2018-04-11', '2018-04-18', 1, 'Segurança pública', 0001, 'A pesquisa se propôs a investigar os elementos estruturais e ideológicos que fomentam o uso abusivo da prisão provisória no Brasil, mais especificamente em seis estados da Federação: Distrito Federal, Rio Grande do Sul, Paraíba, Tocantins, Santa Catarina e São Paulo. Para tanto, buscou-se identificar quais as modificações implementadas em cada um dos seis estados pesquisados, mais especificamente em suas capitais, no âmbito do Poder Judiciário, para a implementação das Audiências de Custódia e das medidas cautelares no processo penal. Também foi analisada a percepção dos operadores jurídicos envolvidos com a implementação das audiências sobre suas potencialidades, assim como sobre as dificuldades para a sua implementação.', 1),
(0003, '2018-04-10', '2018-04-10', 1, 'Pesquisa teste', 0001, 'Todavia, o desenvolvimento contínuo de distintas formas de atuação assume importantes posições no estabelecimento do impacto na agilidade decisória. Do mesmo modo, a consolidação das estruturas aponta para a melhoria do processo de comunicação como um todo. As experiências acumuladas demonstram que o fenômeno da Internet promove a alavancagem das condições inegavelmente apropriadas. Gostaria de enfatizar que o aumento do diálogo entre os diferentes setores produtivos facilita a criação dos índices pretendidos. A certificação de metodologias que nos auxiliam a lidar com a adoção de políticas descentralizadoras estimula a padronização dos conhecimentos estratégicos para atingir a excelência. ', 1),
(0005, '0000-00-00', '0000-00-00', 0, 'Consumo de substâncias quimicas', 0001, 'Pesquisa que visa compreender a relação da sociedade com o uso de substâncias químicas que causam dependência.', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pesquisa_login`
--

CREATE TABLE `pesquisa_login` (
  `id_pesquisa_login` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `id_pesquisa` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `id_login` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pesquisa_login`
--

INSERT INTO `pesquisa_login` (`id_pesquisa_login`, `id_pesquisa`, `id_login`, `status`) VALUES
(0001, 0003, 0001, 0),
(0002, 0001, 0001, 0),
(0003, 0001, 0003, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `questao`
--

CREATE TABLE `questao` (
  `id_questao` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `id_pesquisa` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `tipo` int(1) NOT NULL,
  `texto` text NOT NULL,
  `a` varchar(200) NOT NULL,
  `b` varchar(200) NOT NULL,
  `c` varchar(200) NOT NULL,
  `d` varchar(200) NOT NULL,
  `e` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `questao`
--

INSERT INTO `questao` (`id_questao`, `id_pesquisa`, `tipo`, `texto`, `a`, `b`, `c`, `d`, `e`) VALUES
(0001, 0001, 0, 'Em que área da administração pública a cidade de São Gonçalo mais deixa a desejar?', 'Segurança', 'Saúde', 'Educação', 'Coleta de lixo', 'Urbanização'),
(0002, 0001, 0, 'Como resolver o problema de segurança pública na cidade a curto prazo?', 'Aumento do policiamento nos bairros', 'Criação de uma plataforma colaborativa', 'Atuação mais direta da polícia militar contra o tráfico de drogas', 'Combater o aumento de roubo de cargas', 'Criar postos de monitoramento nas áreas mais sensíveis da cidade');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `escolha`
--
ALTER TABLE `escolha`
  ADD PRIMARY KEY (`id_escolha`);

--
-- Indexes for table `follow`
--
ALTER TABLE `follow`
  ADD PRIMARY KEY (`id_follow`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id_login`);

--
-- Indexes for table `pesquisa`
--
ALTER TABLE `pesquisa`
  ADD PRIMARY KEY (`id_pesquisa`);

--
-- Indexes for table `pesquisa_login`
--
ALTER TABLE `pesquisa_login`
  ADD PRIMARY KEY (`id_pesquisa_login`);

--
-- Indexes for table `questao`
--
ALTER TABLE `questao`
  ADD PRIMARY KEY (`id_questao`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `escolha`
--
ALTER TABLE `escolha`
  MODIFY `id_escolha` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `follow`
--
ALTER TABLE `follow`
  MODIFY `id_follow` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id_login` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pesquisa`
--
ALTER TABLE `pesquisa`
  MODIFY `id_pesquisa` int(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pesquisa_login`
--
ALTER TABLE `pesquisa_login`
  MODIFY `id_pesquisa_login` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `questao`
--
ALTER TABLE `questao`
  MODIFY `id_questao` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
