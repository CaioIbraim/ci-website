
<div class="section section-images">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Seguindo</h3>
                  <p>{seguindo}</p>
            </div>
            <div class="col-md-6">
                <h2>Sugestões</h3>
                  <p>{sugest}</p>
            </div>
        </div>
    </div>
</div>
