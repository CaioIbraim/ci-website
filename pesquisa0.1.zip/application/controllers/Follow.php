<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Follow extends MY_Controller {

    public function __construct() {
      parent::__construct();
      $this->data['title'] = 'Contatos';
      $this->data['url_pagina'] = base_url().''.$this->uri->segment(1);
      if($this->session->login === NULL || $this->session->login === FALSE){
        redirect('login/logout');
      }
    }

    public function index() {
      //Retornar usuários que ainda não foram seguidos
      $id = $this->session->id;

      $seg = $this->db->query('select id_login, perfil, nome, cel, email from login left join follow on followed <> '.$id.' where follow.status = 2 and follower = '.$id.'')->result_array();

      if(count($seg) === 0){
          $this->data['seguindo'] = 'Você não está seguindo nenhum usuário até o momento.';
      }

      //Criar função para retornar todos os usuários de forma dinâmica
      $sugest = $this->db->query('select id_login, perfil, nome, cel, email from login left join follow on followed <> '.$id.' where  id_login <> '.$id.' limit 10')->result_array();
      $this->data['sugest'] = $this->htmlSugest($sugest); //Criar função para formatar html com as sugestões

      $this->data['conteudo'] = $this->parser->parse('telas/followed',$this->data,true);
      $this->parser->parse('layout/landing', $this->data);
    }

    public function follo($id_post){
      $data['follower'] =  $this->session->id;
      $data['followed'] =  $id_post;
      $data['status']   =  0;
      $this->load->model('Crud_model', 'p');
      $query = $this->p->insert($dados,'follow');
    }



    public function htmlSugest($dados){
        //  var_dump($dados); die();
        $url = base_url();
        $html = '';

        for($i = 0; $i < count($dados); $i++){
          $html  .= '<div class="space-50"></div>
                      <div class="container text-center">
                          <div class="row">
                              <div class="col">
                                  <p>'.$dados[$i]['nome'].'</p>
                                  <a href="'.$url.'conta/exibir/'.$dados[$i]['id_login'].'" class="btn btn-simple btn-primary btn-round">Ver contato</a>
                              </div>
                          </div>
                  </div>';
        }

        return $html;
    }


}
