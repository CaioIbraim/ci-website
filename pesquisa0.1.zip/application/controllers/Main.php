<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends MY_Controller {

    public function __construct() {
      parent::__construct();
      $this->data['title'] = 'Bem vindo';
      $this->data['url_pagina'] = base_url().''.$this->uri->segment(1);
      if($this->session->login === NULL || $this->session->login === FALSE){
        redirect('login/logout');
      }
    }

    public function index() {
        $this->data['conteudo'] = $this->parser->parse('telas/main',$this->data,true);
        $this->parser->parse('layout/landing', $this->data);
    }
}
