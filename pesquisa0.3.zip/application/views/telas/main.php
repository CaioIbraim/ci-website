


  <div class="page-header-image">
        </div>
        <div class="container">
            <div class="content-center brand">
                <h1 class="h1-seo">Plataforma de pesquisas</h1>
                 <a href="<?= base_url();?>pesquisas/cadastrarPesquisa"><h3>Contribua com uma pesquisa.</h3></a>
                <p>Software de pesquisa & inquéritos online - ideal para avaliação de desempenho, pesquisa de satisfação, pesquisa de mercado e muito mais. Crie um questionário e analise as respostas.</p>
            </div>
   </div>

       <div class="container">
         <hr>
                 {pesquisas}
                        <div class="row">
                              <div class="col-md-6">
                                <h4 class="title">{titulo}</h4>
                              </div>
                              <div class="col-md-6">
                                <h6 class="title">{participacao}</h6>
                                <p><small class="title"> {status} </small></p>
                                <p><small class="title"> Autor da pesquisa : {nome} </small></p>
                                <a href="<?= base_url();?>pesquisas/info/{id_pesquisa}" class="btn btn-primary btn-icon btn-round"><i class="fa fa-university"></i></a><a href="<?= base_url();?>pesquisas/questao/{id_pesquisa}" class="btn btn-primary btn-icon btn-round"><i class="fa fa-check"></i></a>
                             </div>
                        </div>
        <hr>
                 {/pesquisas}
       </div>
