<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends MY_Controller {
	public function index()
	{
			$this->data ['blog_title'] = 'Home|website';
			$this->parser->parse('index', $this->data);
	}
}
