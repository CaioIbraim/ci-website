<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MY_Controller extends CI_Controller {

public $data;

public function __construct()
{
	parent::__construct();
	$this->load->library('parser');
  $this->data =  array('menu'       => $this->retornaMenu(), 'banner' => $this->retornaBanner(3));
}


//Monta o slide principal
public function showSlide(){
  $nouser_list_template = '<div class="item">
														<a href="{link}" target="_blank">
														 <img src="/ci-site/gp/images/{img}" class="img-responsive" alt="">
														</a>
													</div>';

  $nousers = $this->retornaSlide();

  $base_list = ' 	<div id="carousel-slider" class="carousel slide" data-ride="carousel">
									<!-- Indicators -->
								  	<ol class="carousel-indicators visible-xs">
									    <li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
									    <li data-target="#carousel-slider" data-slide-to="1"></li>
									    <li data-target="#carousel-slider" data-slide-to="2"></li>
								  	</ol>
				        	<div class="carousel-inner">';
  foreach ($nousers as $user)
  {
    $base_list .= $this->parser->parse_string($nouser_list_template, $user, TRUE);
  }
  $base_list .= '
						</div>

						<a class="left carousel-control hidden-xs" href="#carousel-slider" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>

						<a class=" right carousel-control hidden-xs"href="#carousel-slider" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div> <!--/#carousel-slider-->';

	return $base_list;
}


//Nesta função eu informo o número de banners que eu desejo se sejam exibidos,
//podendo ser chamada em uma tela que me permita apresentar todos os banners ou apenas um número pré estabelecido
public function retornaBanner($n){
  $this->load->model('website', 'banner');
  $banner = $this->banner->get_banners($n);
  $a = array();
  for($i = 0; $i < sizeof($banner); $i++){
		$a[$i] = array('img' => $banner[$i]->img_url, 'link' => '#');
	}
	return $a;
}

 //Formata o Array para apresentar o slide
public function retornaSlide(){
	$this->load->model('website', 'site');
	$slide = $this->site->get_slides();
	$a = array();
  for($i = 0; $i < sizeof($slide); $i++){
		$a[$i] = array('img' => $slide[$i]->img_url, 'link' => '#');
	}
	return $a;
}

//Formata o Array para apresentar o menu
public function retornaMenu(){
 		$this->load->model('website', 'menu');
 		$menu = $this->menu->get_menu();
 		$a = array();

 		for($i = 0; $i < sizeof($menu); $i++){
 			$a[$i] = array('titulo' => $menu[$i]->titulo, 'link' => $menu[$i]->link_pg);
 		}
 		return $a;
 	}



}
