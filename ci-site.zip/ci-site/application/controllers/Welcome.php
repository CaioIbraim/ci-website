<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends CI_Controller {

	public function index()
	{
			$this->load->library('parser');

			$data = array(
		        'blog_title' => 'CI Web Site',
						'menu'       => $this->retornaMenu()
		  );


			$this->parser->parse('index', $data);
	}



 //Formata o Array para apresentar o slide
	public function retornaSlide(){
		$this->load->model('website', 'site');
		$slide = $this->site->get_slides();
		$a = array();

		for($i = 0; $i < sizeof($slide); $i++){
			$a[$i] = array('img' => $slide[$i]->img_url, 'link' => '#');
		}
		return $a;
	}


	//Formata o Array para apresentar o menu
 	public function retornaMenu(){
 		$this->load->model('website', 'menu');
 		$menu = $this->menu->get_menu();
 		$a = array();

 		for($i = 0; $i < sizeof($menu); $i++){
 			$a[$i] = array('titulo' => $menu[$i]->titulo, 'link' => $menu[$i]->link_pg);
 		}
 		return $a;
 	}



}
