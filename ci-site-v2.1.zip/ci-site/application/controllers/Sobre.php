<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Sobre extends MY_Controller {
	public function index()
	{
			$this->data ['blog_title']  = 'Sobre|website';
			$this->data['titulo']       = 'Quem somos';
			$this->data['subtitulo']    = '';
			$this->data['conteudo']     = parent::retornaConteudo('sobre');

			$this->parser->parse('page', $this->data);
	}
}
