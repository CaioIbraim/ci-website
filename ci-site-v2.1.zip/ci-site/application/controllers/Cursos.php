<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cursos extends MY_Controller {
	public function index()
	{
			$this->data ['blog_title']  = 'Cursos|website';
			$this->data['titulo']       = 'Cursos';
			$this->data['subtitulo']    = '';
			$this->data['conteudo']     = parent::retornaConteudo('cursos');
			$this->parser->parse('page', $this->data);
	}
}
