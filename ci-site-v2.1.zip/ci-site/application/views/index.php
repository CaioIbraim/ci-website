<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{blog_title}</title>

    <!-- Bootstrap -->
  <link href="/ci-site/gp/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/ci-site/gp/css/font-awesome.min.css">
	<link href="/ci-site/gp/css/animate.min.css" rel="stylesheet">
  <link href="/ci-site/gp/css/prettyPhoto.css" rel="stylesheet">
	<link href="/ci-site/gp/css/style.css" rel="stylesheet">
	<link href="/ci-site/gp/css/responsive.css" rel="stylesheet">





  </head>
  <body class="homepage">


    <div class="container">

<!-- Este bloco será apresentado sempre que a variável slide existir -->

<div class="row">
  <div class="col-md-12 col-sm-6 col-xs-12">
    <div class="slider">
  		<div class="container">
  			<div id="about-slider">
             <img src="/ci-site/gp/images/slider_tree.png" class="img-responsive" alt="">
  			</div>
  		</div>
  	</div>
  </div>
</div>

<!--/#about-slider-->


<header id="header">
 <nav class="navbar-custom">
     <div class="container">
         <div class="navbar-header">
             <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                 <span class="sr-only">Toggle navigation</span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
             </button>

         </div>

         <div class="collapse navbar-collapse navbar-left">
             <ul class="nav navbar-nav">
               {menu}
                 <li><a  href="<?= base_url(); ?>index.php/{link}">{titulo}</a></li>
               {/menu}
             </ul>
         </div>
     </div><!--/.container-->
 </nav><!--/nav-->
</header><!--/header-->



	 <section id="feature" >
        <div class="container-fluid">
            <div class="col-md-8 col-sm-8 col-xs-8">

<!-- Apresentar Banner caso exista -->
<?php if(isset($slide)){ ?>
                                <div class="row">
                                    <div class="features">
                                        <div class="col-md-12">
                                            <div class="feature-wrap">
                                                <!-- Este bloco será apresentado sempre que a variável slide existir -->
                                                <div class="row">
                                                  <div class="col-md-12 col-sm-6 col-xs-12">
                                                    <div class="slider">
                                                      <div class="container-fluid">
                                                        <div id="about-slider">
                                                              {slide}
                                                        </div>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <!--/#about-slider-->
                                            </div>
                                        </div><!--/.col-md-4-->
                                    </div><!--/.services-->
                                </div><!--/.row-->
<?php  }?>


                        <div class="row">
                            <div class="features">
                                <div class="col-md-12 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                                    <div class="feature-wrap">
                                        <i class="fa fa-laptop"></i>
                                        <h2>Fresh and Clean</h2>
                                        <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit Lorem ipsum dolor sit amet, consectetur adipisicing elit Lorem ipsum dolor sit amet, consectetur adipisicing elit
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elitLorem ipsum dolor sit amet, consectetur adipisicing elitLorem ipsum dolor sit amet, consectetur adipisicing elitLorem ipsum dolor sit amet, consectetur adipisicing elit</h3>
                                    </div>
                                </div><!--/.col-md-4-->
                            </div><!--/.services-->
                        </div><!--/.row-->
            </div>


            <!-- Segunda coluna -->

            <div class="col-md-4 col-sm-4 col-xs-4">

              <div class="row">
                <div class="feature-wrap">
                   <h2>ARTIGOS EM DESTAQUE</h2>
                   <hr>
                      <small>2.10.2017</small>
                    <a href="http://ensinandodesiao.org.br/artigos-e-estudos/zman-simchatenu-tempo-da-nossa-alegria/" target="_blank">
                      <h4>Zman Simchatenu – Tempo da Nossa Alegria!</h4>
                      A festa de Sucôt (Tabernáculos ou Tendas) é a maior das festas bíblicas.
                      Ela é a única festa que é chamada de “A Festa” (Lv 23:39) e com certeza é a festa bíblica com maior significado profético.
                      Durante as bênçãos de Sucot, declaramos: “Zman Simchatenu” – Tempo da nossa alegria! Vejamos o mandamento divino para Israel
                    </a>
                  <hr>
                </div>
              </div>



  {banner}
              <div class="row">
                <div class="feature-wrap">
                    <a  href="<?= base_url(); ?>index.php/{link}"><img class="img-responsive" src="/ci-site/gp/images/portfolio/recent/{img}" alt=""></a>
                </div>
              </div>
{/banner}

            </div>
            <!-- Fim da segunda coluna -->

        </div><!--/.container-->
    </section><!--/#feature-->
</div> <!-- Continer principal-->


	<section id="bottom">
        <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        <h3>Company</h3>
                        <ul>
                            <li><a href="#">About us</a></li>
                            <li><a href="#">We are hiring</a></li>
                            <li><a href="#">Meet the team</a></li>
                            <li><a href="#">Copyright</a></li>
                        </ul>
                    </div>
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        <h3>Support</h3>
                        <ul>
                            <li><a href="#">Faq</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Forum</a></li>
                            <li><a href="#">Documentation</a></li>
                        </ul>
                    </div>
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        <h3>Developers</h3>
                        <ul>
                            <li><a href="#">Web Development</a></li>
                            <li><a href="#">SEO Marketing</a></li>
                            <li><a href="#">Theme</a></li>
                            <li><a href="#">Development</a></li>
                        </ul>
                    </div>
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        <h3>Our Partners</h3>
                        <ul>
                            <li><a href="#">Adipisicing Elit</a></li>
                            <li><a href="#">Eiusmod</a></li>
                            <li><a href="#">Tempor</a></li>
                            <li><a href="#">Veniam</a></li>
                        </ul>
                    </div>
                </div><!--/.col-md-3-->
            </div>
        </div>
    </section><!--/#bottom-->

	<div class="top-bar">
		<div class="container">
			<div class="row">
			    <div class="col-lg-12">
				   <div class="social">
						<ul class="social-share">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
							<li><a href="#"><i class="fa fa-skype"></i></a></li>
						</ul>
				   </div>
                </div>
			</div>
		</div><!--/.container-->
	</div><!--/.top-bar-->




	<footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; MBM. Todos Direitos Reservados.
                    <div class="credits">
                        <a href="">Desenvolvido</a> por: <a href="">Caio Ibraim</a>
                    </div>
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Faq</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="/ci-site/gp/js/jquery.js"></script>
    <script src="/ci-site/gp/js/bootstrap.min.js"></script>
    <script src="/ci-site/gp/js/jquery.prettyPhoto.js"></script>
    <script src="/ci-site/gp/js/jquery.isotope.min.js"></script>
    <script src="/ci-site/gp/js/wow.min.js"></script>
  	<script src="/ci-site/gp/js/main.js"></script>

    <script>
        $('.carousel-inner .item:first-child').addClass('active');
    </script>




</body>
</html>
