-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 11-Out-2017 às 18:31
-- Versão do servidor: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci_website`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `banner`
--

CREATE TABLE `banner` (
  `id_banner` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `img_url` varchar(120) NOT NULL,
  `link_pg` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `banner`
--

INSERT INTO `banner` (`id_banner`, `img_url`, `link_pg`) VALUES
(0001, 'item1.png', '#'),
(0002, 'item2.png', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `conteudo`
--

CREATE TABLE `conteudo` (
  `id_conteudo` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `pagina` varchar(16) NOT NULL,
  `conteudo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `conteudo`
--

INSERT INTO `conteudo` (`id_conteudo`, `pagina`, `conteudo`) VALUES
(0001, 'sobre', 'O Ministério Ensinando de Sião (AMES, Brasil ? www.ensinandodesiao.org.br) é uma instituição de ensino bíblico, composta por não-judeus, descendentes de judeus e judeus. Apregoamos o ensino e a obediência aos Escritos judaicos da Torá (Pentateuco), dos Neviim (Profetas), dos Ketuvim (escritos) e da Brit Chadashá (Nova Aliança – Jr 31:31). Com base em tais Escritos, cremos ser Yeshua haMashiach o Messias de Israel e veículo da redenção do Eterno, sendo primeiramente enviado há 2000 anos como “Mashiach Ben Yossef”, mas que em breve voltará trazendo redenção e paz para os da Casa de Israel e para todas as nações como “Mashiach Ben David”. O Ministério Ensinando de Sião é filiado ao Netivyah Bible Instruction Ministry (Jerusalém, Israel ? www.netivyah.org) e reconhecido pela Union of Messianic Jewish Congregations (UMJC, EUA ? www.umjc.org), pelo Messianic Jewish Bible Institute (MJBI, EUA ? www.mjbi.org), pela Tikkun International Mission (Israel e EUA ? www.tikkunministries.org) e pelo Jewish Voice Ministries International (EUA ? www.jewishvoice.org), dentre outras federações e entidades judaico-messiânicas internacionais reconhecidas em Israel e nos Estados Unidos da América.\r\n'),
(0002, 'cursos', ' <ul class=\"list-group\">\r\n  <li class=\"list-group-item\">Curso de Hebraico</li>\r\n  <li class=\"list-group-item\">Bacharelado em Teologia</li>\r\n  <li class=\"list-group-item\">Seminário de Teologia</li>\r\n</ul> ');

-- --------------------------------------------------------

--
-- Estrutura da tabela `menu`
--

CREATE TABLE `menu` (
  `id_menu` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `titulo` varchar(12) NOT NULL,
  `link_pg` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `menu`
--

INSERT INTO `menu` (`id_menu`, `titulo`, `link_pg`) VALUES
(0001, 'Home', 'home'),
(0002, 'Sobre', 'sobre'),
(0003, 'Cursos', 'cursos');

-- --------------------------------------------------------

--
-- Estrutura da tabela `slide`
--

CREATE TABLE `slide` (
  `id_baner` smallint(4) UNSIGNED ZEROFILL NOT NULL,
  `img_url` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `slide`
--

INSERT INTO `slide` (`id_baner`, `img_url`) VALUES
(0001, 'slider_one.jpg'),
(0002, 'slider_one.jpg'),
(0003, 'slider_one.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id_banner`);

--
-- Indexes for table `conteudo`
--
ALTER TABLE `conteudo`
  ADD PRIMARY KEY (`id_conteudo`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id_baner`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id_banner` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `conteudo`
--
ALTER TABLE `conteudo`
  MODIFY `id_conteudo` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `id_baner` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
