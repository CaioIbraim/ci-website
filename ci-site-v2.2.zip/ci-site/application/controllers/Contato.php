<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Contato extends MY_Controller {

public function __construct(){
	parent::__construct();

	$this->data['blog_title']  = 'Contato|website';
	$this->data['titulo']       = 'Contato';
	$this->data['subtitulo']    = '';
	$this->data['conteudo']     = parent::retornaPainelLogin();
}

	public function index()
	{
			$this->parser->parse('page', $this->data);
	}

public function inserir(){


  $this->load->library('form_validation');

	$this->form_validation->set_rules('nome', 'Nome', 'required', array('required' => 'Por favor informe seu %s.'));
	$this->form_validation->set_rules('email', 'Email', 'required',
					array('required' => 'Por favor informe seu %s.')
	);
	$this->form_validation->set_rules('tel', 'Celular', 'required', array('required' => 'Por favor informe seu %s.'));
	$this->form_validation->set_rules('mensagem', 'Mensagem', 'required', array('required' => 'Por favor preencha o campo %s.'));

	if ($this->form_validation->run() == FALSE)
	{
					$this->data['mensagens'] = array('erros' => validation_errors());


				 $this->parser->parse('page', $this->data);

	}
	else
	{
				$this->load->model('website');
					// Recupera os dados do formulário
					$contato = $this->input->post();
					// Insere os dados no banco recuperando o status dessa operação
					$this->load->model('website');
					$this->website->insert_contato($contato);

					redirect('contato');
	}


}


}
