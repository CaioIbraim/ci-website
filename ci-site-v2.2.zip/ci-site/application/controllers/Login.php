<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends MY_Controller {
	public function index()
	{
			$this->data ['blog_title']  = 'Contato|website';
			$this->data['titulo']       = 'Contato';
			$this->data['subtitulo']    = '';
			$this->data['conteudo']     = '';
			$this->parser->parse('page', $this->data);
	}
}
