<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Estudos extends MY_Controller {
	public function index()
	{
			$this->data ['blog_title']  = 'Estudos|website';
			$this->data['titulo']       = 'Estudos e Artigos';
			$this->data['subtitulo']    = '';

			$this->load->model('website');

					$config = array(
						"base_url" => base_url('estudos/p'),
						"per_page" => 3,
						"num_links" => 3,
						"uri_segment" => 3,
						"total_rows" => $this->website->CountAll(),
						"full_tag_open" => "<ul class='pagination'>",
						"full_tag_close" => "</ul>",
						"first_link" => FALSE,
						"last_link" => FALSE,
						"first_tag_open" => "<li>",
						"first_tag_close" => "</li>",
						"prev_link" => "Anterior",
						"prev_tag_open" => "<li class='prev'>",
						"prev_tag_close" => "</li>",
						"next_link" => "Próxima",
						"next_tag_open" => "<li class='next'>",
						"next_tag_close" => "</li>",
						"last_tag_open" => "<li>",
						"last_tag_close" => "</li>",
						"cur_tag_open" => "<li class='active'><a href='#'>",
						"cur_tag_close" => "</a></li>",
						"num_tag_open" => "<li>",
						"num_tag_close" => "</li>"
					);
					$this->pagination->initialize($config);
					$this->data['pagination'] = $this->pagination->create_links();
					$offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
					$this->data['conteudo'] = $this->website->GetAll('id_post','desc',$config['per_page'],$offset);
					$this->parser->parse('list_post', $this->data);
	}


	public function exibe($id_post)
	{
		//Recuperar conteúdo do post
		$this->load->model('website', 'post');
		$post = $this->post->get_postById($id_post);

		$this->data ['blog_title']  = $post[0]['titulo']."|website";
		$this->data['titulo']       = $post[0]['titulo'];
		$this->data['subtitulo']    = $post[0]['data'] . ' '. $post[0]['autor'];
		$this->data['conteudo']     = $post[0]['texto'];
		$this->parser->parse('post', $this->data);
	}

}
