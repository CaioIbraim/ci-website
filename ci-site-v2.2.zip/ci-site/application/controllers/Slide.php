<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//APRESENTA INFORMAÇÕES SOBRE O BANNER
class Slide extends MY_Controller {
	public function index()
	{
			$this->data ['blog_title']  = 'Anuncios|website';
			$this->data['titulo']       = 'Anuncios';
			$this->data['subtitulo']    = '';
			$this->data['conteudo']     = parent::retornaAnuncios('sobre');
			$this->parser->parse('page', $this->data);
	}

  public function exibe($id_banner)
	{
		//Recuperar conteúdo do post
		$this->load->model('website', 'banner');
		$banner = $this->banner->get_anuncioById($id_banner, 'slide', 'id_slide');

		$img = "<img class='img-responsive' src='/ci-site/gp/images/{$banner[0]['img_url']}'></a>";

		$this->data ['blog_title']  = $banner[0]['titulo']."|website";
		$this->data['titulo']       = $banner[0]['titulo'];
		$this->data['subtitulo']    = $img;
		$this->data['conteudo']     = $banner[0]['conteudo'];
		$this->parser->parse('page', $this->data);
	}

}
