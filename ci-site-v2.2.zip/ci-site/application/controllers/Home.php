<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends MY_Controller {
	public function index()
	{
			$this->data ['blog_title']  = 'Home|website';
			$this->data['titulo']       = 'Conteúdo';
			$this->data['subtitulo']    = 'Conteúdo';
			$this->data['conteudo']     = 'Conteúdo';
      $this->data ['slide']       = parent::showSlide(); //Pega o slide
			$this->data['sobre']        = parent::retornaConteudo('sobre');
			

			$this->parser->parse('index', $this->data);
	}
}
