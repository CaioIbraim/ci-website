<?php
class Website extends CI_Model {

        public $title;
        public $content;
        public $date;

        public function get_slides()
        {
                $query = $this->db->get('slide', 3);
                return $query->result();
        }


        public function get_banners($n)
        {
                $query = $this->db->get('banner', $n);
                return $query->result();
        }


        public function get_menu()
        {
            $query = $this->db->get('menu');
            return $query->result();
        }



        public function get_conteudo($pg)
        {
          $this->db->select('conteudo');
          $query = $this->db->get_where('conteudo', array('pagina' => $pg));
          return $query->result_array();
        }

        public function get_post()
        {
          $query = $this->db->get('post');
          return $query->result_array();
        }

        public function get_lastPost()
        {
          $query = $this->db->query("SELECT * FROM `post` ORDER  BY id_post DESC LIMIT 1;");
          return $query->result_array();
        }


        public function get_postById($id_post)
        {
          $query = $this->db->get_where('post', array('id_post' => $id_post));
          return $query->result_array();
        }


        public function get_anuncioById($id_banner, $table, $id_name)
        {
          $query = $this->db->get_where($table, array($id_name => $id_banner));
          return $query->result_array();
        }







  /*
  INSERT E UPDATE
  */
        public function insert_contato($contato)
        {
                $this->db->insert('contato', $contato);
        }

        public function update_entry()
        {
                $this->title    = $_POST['title'];
                $this->content  = $_POST['content'];
                $this->date     = time();

                $this->db->update('entries', $this, array('id' => $_POST['id']));
        }

/*
PAGINAÇÃO
*/

function GetAll($sort = 'id_post', $order = 'desc', $limit = null, $offset = null) {
    $this->db->order_by($sort, $order);
    if($limit){
      $this->db->limit($limit,$offset);
    }

    $query = $this->db->get('post');
    if ($query->num_rows() > 0) {
      return $query->result();
    } else {
      return null;
    }

  }

  function CountAll(){
    return $this->db->count_all('post');
  }

}
