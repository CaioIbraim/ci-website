<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MY_Controller extends CI_Controller {

public $data;


public function __construct()
{
	parent::__construct();
	$this->load->library('parser');
  $this->data =  array('menu'       => $this->retornaMenu(), 'banner' => $this->retornaBanner(3));
	$this->data['lastPost']  = $this->retornaLastPost();
}

//retorna o ultimo post
public function retornaLastPost(){
	$this->load->model('website');
	return $this->website->get_lastPost();
}

//Monta o slide principal
public function showSlide(){
  $slide_list_template = '<div class="item">
														{tag}
													</div>';

  $slides = $this->retornaSlide();

  $base_list = ' 	<div id="carousel-slider" class="carousel slide" data-ride="carousel">
									<!-- Indicators -->
								  	<ol class="carousel-indicators visible-xs">
									    <li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
									    <li data-target="#carousel-slider" data-slide-to="1"></li>
									    <li data-target="#carousel-slider" data-slide-to="2"></li>
								  	</ol>
				        	<div class="carousel-inner">';
  foreach ($slides as $slide)
  {
    $base_list .= $this->parser->parse_string($slide_list_template, $slide, TRUE);
  }
  $base_list .= '
						</div>

						<a class="left carousel-control hidden-xs" href="#carousel-slider" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>

						<a class=" right carousel-control hidden-xs"href="#carousel-slider" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div> <!--/#carousel-slider-->';

	return $base_list;
}





public function retornaPainelLogin(){

		$url = base_url();




		$tag = '<div class="row contact-wrap">
				<div class="col-sm-8 col-sm-offset-2">
						<div id="sendmessage">Your message has been sent. Thank you!</div>
						<div id="errormessage"></div>
						<form action="'.$url.'contato/inserir" method="post" role="form" class="contactForm">
								<div class="form-group">
										<input type="text" name="nome" class="form-control" id="name" placeholder="Digite seu nome" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
										<div class="validation"></div>
								</div>
								<div class="form-group">
										<input type="email" class="form-control" name="email" id="email" placeholder="Digite seu email" data-rule="email" data-msg="Please enter a valid email" />
										<div class="validation"></div>
								</div>
								<div class="form-group">
										<input type="text" class="form-control" name="tel" id="subject" placeholder="Digite seu celular" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
										<div class="validation"></div>
								</div>
								<div class="form-group">
										<textarea class="form-control" name="mensagem" rows="5" data-rule="required" data-msg="Deixe a sua mensagem" placeholder="Deixe a sua mensagem"></textarea>
										<div class="validation"></div>
								</div>
								<div class="text-center"><button type="submit" class="btn btn-primary btn-lg">Enviar</button></div>
						</form>
				</div>
		</div>';

		return $tag;

}




//Nesta função eu informo o número de banners que eu desejo se sejam exibidos,
//podendo ser chamada em uma tela que me permita apresentar todos os banners ou apenas um número pré estabelecido
public function retornaBanner($n){
  $this->load->model('website', 'banner');
  $banner = $this->banner->get_banners($n);
  $a = array();
  for($i = 0; $i < sizeof($banner); $i++){

		$tag = "<a href='{$banner[$i]->link_pg}' target='_blank'><img class='img-responsive' src='/ci-site/gp/images/portfolio/recent/{$banner[$i]->img_url}'></a>";
		if($banner[$i]->tipo_link === "0"){
			//se for link interno manda para anuncios
			$url = base_url();
			$tag = "<a href='$url{$banner[$i]->link_pg}/exibe/{$banner[$i]->id_banner}'><img class='img-responsive' src='/ci-site/gp/images/portfolio/recent/{$banner[$i]->img_url}'></a>";
		}

		$a[$i] = array( 'id_banner' => $banner[$i]->id_banner,
		 								'img' 			=> $banner[$i]->img_url,
										'link' 			=> $banner[$i]->link_pg,
										'tag' 			=> $tag
										);
	}
	return $a;
}

 //Formata o Array para apresentar o slide
public function retornaSlide(){
	$this->load->model('website', 'site');
	$slide = $this->site->get_slides();
	$a = array();
  for($i = 0; $i < sizeof($slide); $i++){

	$tag = "<a href='{$slide[$i]->link_pg}' target='_blank'><img class='img-responsive' src='/ci-site/gp/images/{$slide[$i]->img_url}'></a>";
		if($slide[$i]->tipo_link === "0"){
			//se for link interno manda para anuncios
			$url = base_url();
			$tag = "<a href='$url{$slide[$i]->link_pg}/exibe/{$slide[$i]->id_slide}'><img class='img-responsive' src='/ci-site/gp/images/{$slide[$i]->img_url}'></a>";
		}
		$a[$i] = array( 'id_slide' => $slide[$i]->id_slide,
		 								'img' 			=> $slide[$i]->img_url,
										'link' 			=> $slide[$i]->link_pg,
										'tag' 			=> $tag
										);
	}
	return $a;
}

//Formata o Array para apresentar o menu
public function retornaMenu(){
 		$this->load->model('website', 'menu');
 		$menu = $this->menu->get_menu();
 		$a = array();

 		for($i = 0; $i < sizeof($menu); $i++){
 			$a[$i] = array('titulo' => $menu[$i]->titulo, 'link' => $menu[$i]->link_pg);
 		}
 		return $a;
}

//Função para retornar o conteúdo das páginas passando o nome da página como parâmentro
public function retornaConteudo($pg){
	$this->load->model('website', 'conteudo');
	$cont = $this->conteudo->get_conteudo($pg);
	return	$cont[0]['conteudo']; //Estudar maneira de apresentar os conteúdos adicionados
}

//Função para retornar o conteúdo para página tipo post ou estudo
public function retornaPost(){
	$this->load->model('website', 'post');
	return $this->post->get_post();
}

}
